---
name: vine-branches-conversion
description: Write, critique, and rebuild the Vine and Branches Tier 2 landing page and its post-signup confirmation page. Use whenever working on the upgrade page, the trial offer, the headline, the pricing section, the proof section, the message that links to the page, or any question about why the page is or is not converting.
---

# Vine and Branches conversion

You are writing for one page with one job: a Tier 1 member who has been reading a daily scripture message decides to start a paid Tier 2 trial.

Before writing anything, load `reference/landing-page-doctrine.md`. It is the rulebook. Load `reference/copy-checklist.md` before shipping a draft.

## The audience, which is the thing most pages get wrong

This is warm traffic. Every visitor has already been receiving a daily lesson for weeks and tapped a link inside one of those messages. They are not strangers. They do not need to be convinced that daily scripture is worth their time, because they have been living it.

Three consequences:

1. **Short page beats long page.** Cold traffic needs the long scroll. Warm traffic needs the specific new thing Tier 2 adds and the price. Padding it out with education they already have reads as a pitch and costs conversions.
2. **The page must sound like the messages.** Same voice, same restraint. If the daily lesson is quiet and the page is loud, the shift itself is the objection.
3. **Hype tactics backfire harder here than anywhere.** Countdown timers, fake scarcity, "only 3 spots left" in a faith context does not read as urgency. It reads as someone selling God, and it costs trust that took weeks to build.

## The one action

Start the trial. Everything else on the page is subordinate.

No newsletter signup. No "learn more" secondary button competing for the click. No contact form. One action, repeated, with nothing else that looks like it.

## Non-negotiables

- **Price stated plainly, above the fold.** Not after a value stack, not revealed on the next page. In this audience, a hidden price is read as a trick.
- **Say what happens when the trial ends** in the same breath as the trial offer. Exactly when they get charged, exactly how they cancel.
- **The CTA is never below a gate.** No scroll requirement, no timer, no email capture in front of it. The most convinced visitor arrives ready and will leave if they cannot act immediately.
- **Say who it is not for.** It disqualifies the wrong person and makes every other claim more believable.
- **Keep whatever is on the end of the link.** The message carries a member ID as a query parameter. Do not strip it, redirect away from it, or drop it on form submit.

## Order of work

1. Write the confirmation page first. It is the highest-leverage page and the one everyone skips. See the doctrine file.
2. Write the headline and the price block.
3. Write the section that names what Tier 2 actually adds.
4. Write proof.
5. Write the objection section.
6. Only then design.

## Voice

Plain, concrete, unhurried. Short words. No marketing register, no exclamation points, no "unlock" or "transform" or "journey" as a noun. If a sentence would feel strange inside a 6am scripture message, it does not belong on this page either.
