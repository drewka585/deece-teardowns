# Ship checklist

Run every draft against this before it goes live. Any "no" is a rewrite, not a note for later.

## The page

- [ ] The headline says the same thing, in the same words, as the message that links here.
- [ ] A stranger understands what this is within one screen, with no prior context.
- [ ] The price is visible without scrolling.
- [ ] What happens when the trial ends is stated next to the trial offer, including the charge date and how to cancel.
- [ ] There is exactly one action on the page. No secondary button competes with it.
- [ ] The CTA label says what happens next, not "Get started" or "Learn more."
- [ ] Nothing gates the CTA. No email capture, no scroll requirement, no timer.
- [ ] Who it is not for appears near the CTA.
- [ ] Proof sits immediately before the final CTA, not at the top.
- [ ] Proof includes something other than a best-case result.
- [ ] Every section makes sense read on its own.
- [ ] Nothing on the page re-explains what the member already gets every morning.
- [ ] Footer has privacy, terms, and real contact information.
- [ ] The page loads in under 5 seconds.
- [ ] The page keeps whatever is on the end of the URL and carries it through signup.

## The words

- [ ] Read it out loud. If a sentence would sound strange inside a 6am scripture message, cut it.
- [ ] No exclamation points.
- [ ] No countdown, no scarcity, no "spots remaining."
- [ ] No "unlock," "transform," "elevate," "journey" as a noun, "dive in," "game changer."
- [ ] Every claim is either something you can show or something you have cut.
- [ ] Specific beats large. A small sourced number outperforms a big round one.
- [ ] Active voice. People do things, abstractions do not.
- [ ] Read the first sentence alone. Does it make you want the second one?

## The confirmation page

- [ ] It exists. It is not the payment processor's default screen.
- [ ] It answers the questions people actually ask right after signing up.
- [ ] It says plainly how to cancel and when the charge lands.
- [ ] It gives them something to do or read now, while interest is at its peak.

## Before paid traffic, if that ever happens

- [ ] One conversion event fires, and only one.
- [ ] The page matches the specific promise of whatever ad or message sent them.
