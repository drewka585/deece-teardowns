# Landing page doctrine

Distilled from ~40 lessons of paid-traffic CRO teaching (Josiah Colt's 21 Secrets of a High Converting Landing Page, Jeremy Haynes' Call Funnel Mastery, a 10-lesson persuasive writing module, and split-test lessons from three other courses), then translated for a warm-traffic, low-ticket, faith-context upgrade page.

Where the original rule was written for cold paid traffic selling a high-ticket call, the translation is marked. Do not apply the cold-traffic version to this page.

## 1. Page structure

The Four-Step Flow, in this order:

1. **Explanation.** Headline, subheadline, the core value proposition. What Tier 2 is, in one screen.
2. **What it adds, in depth.** Feature, then what that means, then what the member gets out of it. Never a bare feature list.
3. **Social proof.** Immediately before the final call to action, never buried at the top.
4. **The call to action.**

**Translation for warm traffic:** cold traffic gets 8 to 10 standalone sections because visitors skim, skip, and never read linearly. This page does not. The visitor already knows what the daily message is. Four to six sections, each of which has to earn its place. If a section only re-explains something the member already receives every morning, cut it.

Two rules survive the translation intact:

- **Every section has to stand alone.** People skim. A section that only makes sense after reading the one above it is a section most visitors will not understand.
- **Anchor navigation for anything past three screens.** Let the skimmer jump to the question they actually have. People resent being forced to consume in order.

## 2. The headline

Three questions before writing a single word:

- What desire does this audience already run on? Tap it. Never try to create a new one, which is the most expensive move in marketing.
- What do they already know? Everything they have already learned from the daily messages is wasted space on this page.
- How many similar things have they seen? A market that has seen a hundred versions of your promise needs a **named mechanism**, not a bigger promise.

The three-step check for any headline draft:

1. Name the desire, or the thing that solves it.
2. Make it believable.
3. Show that the mechanism lives in this specific product.

Five rules:

- Lead with the reader's self-interest, in every headline.
- If you have real news, state it plainly and large.
- Curiosity is never enough on its own.
- Frame the upside. Save the pain for the body copy.
- Suggest that it is easy without implying a promise you cannot keep.

**The simplicity test.** "We can send money to your email address" beat "tightly integrated financial infrastructure." You know ten times more about this product than the reader does. Cut until a stranger understands it instantly.

The headline's only job is to get the next line read. The subheadline expands the promise and names the mechanism. It never restates the headline in different words.

Five times as many people read the headline as read the body. It is most of the work.

**Do not:** stack audience callouts, use insider language, or make a claim about outcomes you cannot show.

## 3. Price

- **State it early and directly.** Almost no legitimate business hides its price. In an audience built on trust, a hidden price costs more than a high one.
- **Price first, then value.** Never a value stack followed by a discount reveal. It is a trust destroyer and, in some jurisdictions, a compliance problem.
- Stating the price reduces raw signups and raises the quality of the ones you get. That is the trade, and it is worth taking.
- **Say who it is for and who it is not for**, near the call to action.
- **The CTA states exactly what happens next.** Not "Get started." Something closer to "Start the 14 day trial, cancel any time before it ends." Specific labels beat vague ones by a measurable margin.

## 4. Proof

- **Best, worst, and average. Never only the wins.** An all-hits reel reads as staged. A modest result next to a strong one builds more trust than the strong one alone. Buyers hunt for the downside, so get there first.
- **Raw beats designed.** A real screenshot outperforms a styled pull-quote card.
- **Proof should look like the reader.** Same situation, same starting point.
- Put the proof next to the claim it supports, not in a separate testimonials slab.
- **Specific and close to home beats big and abstract.** A large impressive number polls worse than a small, sourced, believable one.
- **Radical transparency is a differentiator** because almost nobody does it. Say what happens if it does not work for them.

**When you have no testimonials yet**, which is the launch case, do not fabricate and do not skip. Use instead: a real sample of the Tier 2 material so they can judge it themselves, a plainly stated founding-member position, the specific reason the thing exists, and a clear no-questions cancellation. Honesty about being early is itself proof of the transparency the rest of the page claims.

## 5. The confirmation page is the highest leverage page in the funnel

This is the page nobody builds and it is worth more than most of the edits above.

Interest peaks at the exact moment someone signs up and decays from there unless new information keeps arriving. A default "thanks, you're in" screen wastes the single highest point of attention you will ever get from that person.

What goes on it:

- A short acknowledgment, ideally on video, framing what happens next.
- Answers to the questions people actually ask after signing up. Every recurring question becomes content here.
- Best, worst, and average proof.

Measured effects from the source material: confirmation-page work alone moved a show rate from around 60 to 65 percent up past 85 percent. Follow-up content answering real questions added 17 percent on average, and 32 percent in one case.

**Translation for a trial:** the equivalent metric is trial-to-paid. The window between "started trial" and "first charge" is the same decaying-interest problem. Answer the cancellation question directly on this page rather than letting it sit unspoken.

Never redirect to a bare third-party confirmation screen.

## 6. Friction

- **Every extra step costs roughly a third of the people who were going to convert.** In the source case, splitting an application and a scheduler across two steps dropped qualified completions by about 50 percent. Combining them into one step brought it to 15 to 16 percent.
- **Do not gate anything behind an email capture** in front of the real action. In roughly 95 percent of audited funnels the opt-in raised cost per real conversion with almost no tracked revenue behind it.
- **Never delay or hide the primary CTA.** No scroll gates, no timers.
- Ask only for what you will actually use.

## 7. Congruence

The page must echo the specific promise of the thing that sent the visitor. For paid traffic that means matching the ad. **Here it means matching the message.** If the message says one thing about Tier 2 and the page opens on a different promise, the mismatch reads as bait and the visitor leaves before the first paragraph.

The practical version: whatever the invitation message says Tier 2 is, the headline says the same thing in the same words.

## 8. Pre-launch gates

- Footer carries a privacy policy, terms, and visible contact information.
- HTTPS enforced.
- Loads in under 5 seconds. 37 percent leave after 5.
- One tracked conversion event, and only one.
- The page preserves query parameters on the URL and carries them through signup.

## 9. Testing

- The first test is two radically different full pages, varying headline, hero, and CTA together. Then iterate off the winner. Small-element tests need traffic volume this page will not have for a while.
- Never wholesale-replace a working page with an unproven one. Test on a slice.
- Fix one variable at a time, starting with whichever stage is furthest below its benchmark.
- Hero video versus hero image is genuinely unsettled. Wistia removed their own hero video and conversions went up. Test it, do not assume.

## 10. Colt's 21, one line each

1 Only sell what actually helps · 2 Know the customer and the product · 3 One consistent visual style · 4 Headline matches the intent that brought them · 5 Subheadline reinforces · 6 Hero image shows the outcome · 7 Four-Step Flow · 8 Typeface matches the feeling · 9 Feature, advantage, benefit · 10 A supporting visual per block · 11 Name the pain, then the relief · 12 Stack multiple kinds of proof · 13 A real guarantee near the CTA · 14 Contrasting CTA colour · 15 Exit-intent recapture · 16 Truthful activity signals only · 17 Under 5 seconds · 18 SSL and trust markers · 19 Compliance footer · 20 One KPI, tracked · 21 Keep testing.

Numbers 15 and 16 are the two to be careful with in this context. An exit-intent popup and a live activity ticker are both technically effective and both read as cheap here. Skip them.
