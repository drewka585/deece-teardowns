/**
 * LinkedIn Session Connector — MV3 background service worker.
 *
 * Reads the client's LIVE li_at + li_a LinkedIn cookies from their own logged-in
 * browser and pushes them to the agency portal on a poll (every CONFIG.POLL_MINUTES)
 * and immediately after activation. Because it reads the live session, the stored
 * cookie is always the current valid one — the client never has to reconnect.
 *
 * MV3 service workers are non-persistent, so all scheduling goes through chrome.alarms.
 */
importScripts('config.js');

const ALARM = 'linkedin-sync';

// ---- storage helpers ----
async function getState() {
  return await chrome.storage.local.get(['token', 'clientName', 'accent', 'status', 'lastPush', 'lastError']);
}
async function setState(patch) {
  await chrome.storage.local.set(patch);
}

// ---- cookie read ----
// Sales Navigator (and cookie-based scrapers) need the FULL session jar, not just
// li_at: JSESSIONID carries the CSRF token, lidc routes to the right datacenter, li_a
// gates Sales Nav. We capture a named allowlist (never "all cookies") to stay within
// the scope the client already granted and keep the privacy story honest.
const WANTED = new Set([
  'li_at', 'li_a', 'JSESSIONID', 'lidc', 'liap', 'bcookie', 'bscookie',
  'li_rm', 'li_gc', 'li_mc', 'lang', 'timezone',
]);

async function collectCookies() {
  const jar = {};
  try {
    const all = await chrome.cookies.getAll({ domain: 'linkedin.com' });
    for (const c of all) {
      if (!WANTED.has(c.name) || !c.value) continue;
      // On duplicate names across sub-domains, keep the longest value.
      if (!jar[c.name] || c.value.length >= jar[c.name].length) jar[c.name] = c.value;
    }
  } catch {
    // fall through with whatever we collected
  }
  return jar;
}

// ---- portal calls ----
async function pushCookies() {
  const { token } = await getState();
  if (!token) return { ok: false, reason: 'not-activated' };

  const jar = await collectCookies();
  const li_at = jar.li_at || '';
  const li_a = jar.li_a || '';

  // li_at is the load-bearing session cookie. If it's gone, the client is logged out
  // of LinkedIn in this browser — report but don't wipe the server's last-good value.
  // `cookies` carries the full jar so the portal can serve a complete Sales Nav session.
  const body = { li_at, li_a, li_a_missing: !li_a, cookies: jar };

  try {
    const res = await fetch(`${CONFIG.PORTAL_BASE}/api/extension/push-cookie`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(body),
    });
    if (res.status === 401) {
      await setState({ status: 'disconnected', lastError: 'Token rejected — please re-enter your activation code.' });
      return { ok: false, reason: 'unauthorized' };
    }
    if (!res.ok) {
      const t = await res.text();
      await setState({ lastError: `Push failed (${res.status})` });
      return { ok: false, reason: t };
    }
    await setState({
      status: li_at ? 'connected' : 'logged-out',
      lastPush: Date.now(),
      lastError: li_at ? null : 'Not logged into LinkedIn in this browser.',
    });
    return { ok: true };
  } catch (e) {
    await setState({ lastError: 'Network error reaching portal.' });
    return { ok: false, reason: String(e) };
  }
}

async function activate(code) {
  try {
    const res = await fetch(`${CONFIG.PORTAL_BASE}/api/extension/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { ok: false, error: data.error || `Activation failed (${res.status})` };
    await setState({
      token: data.token,
      clientName: data.client?.name || 'your account',
      accent: data.client?.accentColor || CONFIG.ACCENT,
      status: 'connected',
      lastError: null,
    });
    // Push immediately so the portal has a fresh cookie the moment they connect.
    await pushCookies();
    return { ok: true, clientName: data.client?.name };
  } catch (e) {
    return { ok: false, error: 'Network error reaching portal.' };
  }
}

async function disconnect() {
  const { token } = await getState();
  if (!token) return { ok: true };
  try {
    const res = await fetch(`${CONFIG.PORTAL_BASE}/api/extension/disconnect`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok && res.status !== 401) {
      return { ok: false, error: `Disconnect failed (${res.status}). Please try again.` };
    }
    await chrome.storage.local.clear();
    return { ok: true };
  } catch {
    return { ok: false, error: 'Could not reach Deece Digital. Your session was not removed; please try again.' };
  }
}

// ---- scheduling ----
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(ALARM, { periodInMinutes: CONFIG.POLL_MINUTES });
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(ALARM, { periodInMinutes: CONFIG.POLL_MINUTES });
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) pushCookies();
});

// ---- popup messaging ----
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg.type === 'activate') sendResponse(await activate(msg.code));
    else if (msg.type === 'push-now') sendResponse(await pushCookies());
    else if (msg.type === 'get-state') sendResponse(await getState());
    else if (msg.type === 'disconnect') sendResponse(await disconnect());
    else sendResponse({ ok: false, error: 'unknown message' });
  })();
  return true; // async response
});
