// White-label + endpoint config for the LinkedIn Session Connector extension.
// Change BRAND_NAME / ACCENT for a client-facing label. If you point at a different
// portal domain, you MUST also update host_permissions in manifest.json to match.
const CONFIG = {
  BRAND_NAME: 'Deece Digital',
  PRODUCT_NAME: 'LinkedIn Connector',
  ACCENT: '#3b5bfd',
  PORTAL_BASE: 'https://portal.deecedigital.com',
  PRIVACY_URL: 'https://deecedigital-site.vercel.app/privacy/linkedin-connector',
  POLL_MINUTES: 5, // background push cadence; on-demand refresh latency is bounded by this
};
