/* Popup UI: activation + live status. All privileged work happens in background.js. */

function send(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));
}
function ago(ts) {
  if (!ts) return 'never';
  const m = Math.floor((Date.now() - ts) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m} min ago`;
  return `${Math.floor(m / 60)} hr ago`;
}
function show(id) {
  document.getElementById(id).classList.remove('hidden');
}
function hide(id) {
  document.getElementById(id).classList.add('hidden');
}

async function render() {
  // Static branding from config
  document.getElementById('brand').textContent = CONFIG.BRAND_NAME;
  document.getElementById('product').textContent = CONFIG.PRODUCT_NAME;
  document.documentElement.style.setProperty('--accent', CONFIG.ACCENT);
  document.getElementById('privacy-link').href = CONFIG.PRIVACY_URL;

  const state = await send({ type: 'get-state' });
  if (!state || !state.token) {
    show('activate-view');
    hide('status-view');
    return;
  }

  hide('activate-view');
  show('status-view');

  if (state.accent) document.documentElement.style.setProperty('--accent', state.accent);

  const dot = document.getElementById('conn-dot');
  const text = document.getElementById('conn-text');
  const status = state.status || 'connected';
  const fresh = state.lastPush && Date.now() - state.lastPush < 15 * 60000;

  if (status === 'connected' && fresh) { dot.className = 'dot green'; text.textContent = 'Connected'; }
  else if (status === 'connected') { dot.className = 'dot amber'; text.textContent = 'Connected (syncing)'; }
  else if (status === 'logged-out') { dot.className = 'dot amber'; text.textContent = 'Not signed into LinkedIn'; }
  else { dot.className = 'dot red'; text.textContent = 'Disconnected'; }

  document.getElementById('account-line').textContent = `Account: ${state.clientName || 'your account'}`;
  document.getElementById('lastpush-line').textContent = `Last synced: ${ago(state.lastPush)}`;

  const errEl = document.getElementById('status-err');
  if (state.lastError) { errEl.textContent = state.lastError; errEl.classList.remove('hidden'); }
  else errEl.classList.add('hidden');

  renderJob(state.job);
}

// v2: show the current saved-search job (if any) with live progress and a Stop control.
function renderJob(job) {
  const panel = document.getElementById('job-panel');
  const jobErr = document.getElementById('job-err');
  if (!job || !job.id) { panel.classList.add('hidden'); return; }
  panel.classList.remove('hidden');

  const dot = document.getElementById('job-dot');
  const title = document.getElementById('job-title');
  const prog = document.getElementById('job-progress');
  const stopBtn = document.getElementById('stop-btn');

  title.textContent = `Search: ${job.label || 'your saved search'}`;
  const counts = `${job.pagesPushed || 0} of ${job.max_pages} pages, ${job.rowsPushed || 0} leads`;

  const showStop = () => { stopBtn.classList.remove('hidden'); stopBtn.disabled = false; stopBtn.textContent = 'Stop search'; };
  const hideStop = () => stopBtn.classList.add('hidden');

  if (job.status === 'running') { dot.className = 'dot blue'; prog.textContent = `Running — ${counts}`; showStop(); }
  else if (job.status === 'completed') { dot.className = 'dot green'; prog.textContent = `Done — ${counts}`; hideStop(); }
  else if (job.status === 'stopped') { dot.className = 'dot amber'; prog.textContent = `Stopped — ${counts}`; hideStop(); }
  else if (job.status === 'error') { dot.className = 'dot red'; prog.textContent = `Stopped — ${counts}`; hideStop(); }
  else { dot.className = 'dot amber'; prog.textContent = 'Queued'; showStop(); }

  if (job.lastError && (job.status === 'error' || job.status === 'running')) {
    jobErr.textContent = job.lastError; jobErr.classList.remove('hidden');
  } else jobErr.classList.add('hidden');
}

function updateActivateState() {
  const code = document.getElementById('code').value.trim();
  const consented = document.getElementById('consent').checked;
  document.getElementById('activate-btn').disabled = !code || !consented;
}

document.getElementById('code').addEventListener('input', updateActivateState);
document.getElementById('consent').addEventListener('change', updateActivateState);

document.getElementById('activate-btn').addEventListener('click', async () => {
  const code = document.getElementById('code').value.trim();
  const errEl = document.getElementById('activate-err');
  errEl.classList.add('hidden');
  if (!code) { errEl.textContent = 'Enter your activation code.'; errEl.classList.remove('hidden'); return; }
  const res = await send({ type: 'activate', code });
  if (!res || !res.ok) {
    errEl.textContent = (res && res.error) || 'Activation failed.';
    errEl.classList.remove('hidden');
    return;
  }
  await render();
});

document.getElementById('push-btn').addEventListener('click', async (e) => {
  e.target.textContent = 'Refreshing…';
  await send({ type: 'push-now' });
  await render();
  document.getElementById('push-btn').textContent = 'Refresh now';
});

document.getElementById('disconnect-btn').addEventListener('click', async () => {
  const button = document.getElementById('disconnect-btn');
  const errEl = document.getElementById('status-err');
  button.disabled = true;
  button.textContent = 'Disconnecting…';
  const result = await send({ type: 'disconnect' });
  if (!result || !result.ok) {
    errEl.textContent = result?.error || 'Disconnect failed. Please try again.';
    errEl.classList.remove('hidden');
    button.disabled = false;
    button.textContent = 'Disconnect';
    return;
  }
  await render();
  button.disabled = false;
  button.textContent = 'Disconnect';
});

// v2: stop a running saved-search job.
document.getElementById('stop-btn').addEventListener('click', async () => {
  const btn = document.getElementById('stop-btn');
  btn.disabled = true;
  btn.textContent = 'Stopping…';
  await send({ type: 'stop-job' });
  await render();
});

// Enter-to-submit on the code field
document.getElementById('code').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('activate-btn').click();
});

render();

// Opening the popup nudges the background to adopt/resume any queued job, and we re-render
// on a short interval so job progress updates live while the popup stays open.
send({ type: 'check-job' });
setInterval(render, 2500);
