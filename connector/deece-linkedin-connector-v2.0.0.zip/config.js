// White-label + endpoint config for the LinkedIn Session Connector extension.
// Change BRAND_NAME / ACCENT for a client-facing label. If you point at a different
// portal domain, you MUST also update host_permissions in manifest.json to match.
const CONFIG = {
  BRAND_NAME: 'Deece Digital',
  PRODUCT_NAME: 'LinkedIn Connector',
  ACCENT: '#3b5bfd',
  PORTAL_BASE: 'https://portal.deecedigital.com',
  PRIVACY_URL: 'https://deecedigital-site.vercel.app/privacy/linkedin-connector',
  POLL_MINUTES: 5, // background push cadence; on-demand refresh latency is bounded by this

  // v2 — Sales Nav saved-search runner. The cadence below is the floor we OBSERVED clean
  // (2.5-5.0s spacing, 20 pages, 2026-08-20). Do not raise the rate because a run looked
  // fine (§7.2). MAX_PAGES is a hard cap — a larger pull is several jobs (§7.6).
  SEARCH_MIN_DELAY_MS: 2500,
  SEARCH_MAX_DELAY_MS: 5000,
  SEARCH_MAX_PAGES: 20,
};
