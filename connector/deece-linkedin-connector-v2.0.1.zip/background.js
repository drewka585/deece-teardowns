/**
 * LinkedIn Session Connector — MV3 background service worker.
 *
 * Reads the client's LIVE li_at + li_a LinkedIn cookies from their own logged-in
 * browser and pushes them to the agency portal on a poll (every CONFIG.POLL_MINUTES)
 * and immediately after activation. Because it reads the live session, the stored
 * cookie is always the current valid one — the client never has to reconnect.
 *
 * MV3 service workers are non-persistent, so all scheduling goes through chrome.alarms.
 */
importScripts('config.js', 'salesnav.js');

const ALARM = 'linkedin-sync';

// ---- storage helpers ----
async function getState() {
  return await chrome.storage.local.get(['token', 'clientName', 'accent', 'status', 'lastPush', 'lastError', 'job']);
}
async function setState(patch) {
  await chrome.storage.local.set(patch);
}

// ---- cookie read ----
// Sales Navigator (and cookie-based scrapers) need the FULL session jar, not just
// li_at: JSESSIONID carries the CSRF token, lidc routes to the right datacenter, li_a
// gates Sales Nav. We capture a named allowlist (never "all cookies") to stay within
// the scope the client already granted and keep the privacy story honest.
const WANTED = new Set([
  'li_at', 'li_a', 'JSESSIONID', 'lidc', 'liap', 'bcookie', 'bscookie',
  'li_rm', 'li_gc', 'li_mc', 'lang', 'timezone',
]);

async function collectCookies() {
  const jar = {};
  try {
    const all = await chrome.cookies.getAll({ domain: 'linkedin.com' });
    for (const c of all) {
      if (!WANTED.has(c.name) || !c.value) continue;
      // On duplicate names across sub-domains, keep the longest value.
      if (!jar[c.name] || c.value.length >= jar[c.name].length) jar[c.name] = c.value;
    }
  } catch {
    // fall through with whatever we collected
  }
  return jar;
}

// ---- portal calls ----
async function pushCookies() {
  const { token } = await getState();
  if (!token) return { ok: false, reason: 'not-activated' };

  const jar = await collectCookies();
  const li_at = jar.li_at || '';
  const li_a = jar.li_a || '';

  // li_at is the load-bearing session cookie. If it's gone, the client is logged out
  // of LinkedIn in this browser — report but don't wipe the server's last-good value.
  // `cookies` carries the full jar so the portal can serve a complete Sales Nav session.
  const body = { li_at, li_a, li_a_missing: !li_a, cookies: jar };

  try {
    const res = await fetch(`${CONFIG.PORTAL_BASE}/api/extension/push-cookie`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(body),
    });
    if (res.status === 401) {
      await setState({ status: 'disconnected', lastError: 'Token rejected — please re-enter your activation code.' });
      return { ok: false, reason: 'unauthorized' };
    }
    if (!res.ok) {
      const t = await res.text();
      await setState({ lastError: `Push failed (${res.status})` });
      return { ok: false, reason: t };
    }
    await setState({
      status: li_at ? 'connected' : 'logged-out',
      lastPush: Date.now(),
      lastError: li_at ? null : 'Not logged into LinkedIn in this browser.',
    });
    return { ok: true };
  } catch (e) {
    await setState({ lastError: 'Network error reaching portal.' });
    return { ok: false, reason: String(e) };
  }
}

async function activate(code) {
  try {
    const res = await fetch(`${CONFIG.PORTAL_BASE}/api/extension/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { ok: false, error: data.error || `Activation failed (${res.status})` };
    await setState({
      token: data.token,
      clientName: data.client?.name || 'your account',
      accent: data.client?.accentColor || CONFIG.ACCENT,
      status: 'connected',
      lastError: null,
    });
    // Push immediately so the portal has a fresh cookie the moment they connect.
    await pushCookies();
    return { ok: true, clientName: data.client?.name };
  } catch (e) {
    return { ok: false, error: 'Network error reaching portal.' };
  }
}

async function disconnect() {
  const { token } = await getState();
  if (!token) return { ok: true };
  try {
    const res = await fetch(`${CONFIG.PORTAL_BASE}/api/extension/disconnect`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok && res.status !== 401) {
      return { ok: false, error: `Disconnect failed (${res.status}). Please try again.` };
    }
    await chrome.storage.local.clear();
    return { ok: true };
  } catch {
    return { ok: false, error: 'Could not reach DeeCe Digital. Your session was not removed; please try again.' };
  }
}

// ============================================================================
// v2 — Sales Navigator saved-search runner
//
// On the SAME alarm loop that pushes cookies, the extension asks the portal whether a
// saved-search job is pending (GET /status -> search_job). If so it runs THAT search here,
// in the client's own logged-in browser, and pushes result pages back one at a time.
//
// Why here and not off-device: the session only works in the browser that owns it. Why
// construct the request instead of intercepting the page: the three headers are rebuildable
// from the live cookie jar (csrf-token = JSESSIONID), so no MAIN-world content script and no
// user click are needed. `start` is the only thing that moves (§4).
//
// The client can always see the run and stop it (popup); a 429/403 hard-stops and never
// retries; pages push incrementally so a run that dies at page 18 keeps 17 pages; and the
// cursor is persisted every page so a browser restart resumes where it left off.
// ============================================================================

let jobRunning = false;   // in-memory re-entrancy guard for the current SW activation
let stopRequested = false; // set by the popup's Stop; the loop checks it every page

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function getJob() {
  const { job } = await chrome.storage.local.get('job');
  return job || null;
}
async function setJob(job) {
  await chrome.storage.local.set({ job });
}

// csrf-token is the live JSESSIONID value, read fresh each page and never stored. Strip the
// surrounding quotes LinkedIn wraps it in.
async function readCsrfToken() {
  try {
    const c = await chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'JSESSIONID' });
    if (!c || !c.value) return '';
    return c.value.replace(/^"|"$/g, '');
  } catch {
    return '';
  }
}

// POST one page (or a terminal signal) to the portal. Returns the parsed body or throws.
async function postResults(token, payload) {
  const res = await fetch(`${CONFIG.PORTAL_BASE}/api/extension/search-results`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
  if (res.status === 401) {
    await setState({ status: 'disconnected', lastError: 'Token rejected — please re-enter your activation code.' });
    throw new Error('unauthorized');
  }
  if (!res.ok) throw new Error(`portal ${res.status}`);
  return res.json().catch(() => ({}));
}

async function reportTerminal(token, jobId, event, reason, httpStatus) {
  try {
    await postResults(token, { job_id: jobId, event, reason, http_status: httpStatus });
  } catch (e) {
    // Best-effort: the job status is also written locally so the popup reflects it even if
    // the portal is briefly unreachable.
  }
}

// Pull the pending job off the portal and adopt it locally. Server hands out the oldest
// pending/running job and claims a pending one as running, so a second poll won't double-run.
async function adoptJobFromStatus() {
  const { token } = await getState();
  if (!token) return;
  let data;
  try {
    const res = await fetch(`${CONFIG.PORTAL_BASE}/api/extension/status`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return;
    data = await res.json();
  } catch {
    return;
  }
  const sj = data && data.search_job;
  if (!sj || !sj.id) return;

  const local = await getJob();
  if (local && local.id === sj.id) {
    // Same job we already track. Keep the furthest-along cursor so we never redo a page that
    // the server already acked (dedupe would absorb it, but skipping is cheaper).
    if (local.status === 'running') {
      const merged = { ...local, nextStart: Math.max(local.nextStart || 0, sj.start || 0) };
      await setJob(merged);
      return;
    }
    // local terminal (completed/stopped/error) but server still lists it: leave it, the
    // terminal report is what closes it server-side; a transient race resolves next poll.
    return;
  }

  // A new job. Adopt it, starting from the server's resume cursor.
  await setJob({
    id: sj.id,
    search_url: sj.search_url,
    label: sj.label || 'your saved search',
    max_pages: Math.min(sj.max_pages || CONFIG.SEARCH_MAX_PAGES, CONFIG.SEARCH_MAX_PAGES),
    nextStart: sj.start || 0,
    pagesPushed: 0,
    rowsPushed: 0,
    status: 'running',
    startedAt: Date.now(),
    lastTickAt: Date.now(),
    lastError: null,
  });
}

// Run (or resume) the current local job to completion, one page at a time.
async function runJob() {
  if (jobRunning) return;
  let job = await getJob();
  if (!job || job.status !== 'running') return;
  const { token } = await getState();
  if (!token) return;

  jobRunning = true;
  stopRequested = false;
  try {
    while (job.pagesPushed < job.max_pages && !stopRequested) {
      const csrf = await readCsrfToken();
      if (!csrf) {
        job.status = 'error';
        job.lastError = 'Not signed into LinkedIn in this browser.';
        await setJob(job);
        await reportTerminal(token, job.id, 'error', job.lastError, null);
        break;
      }

      const count = SNAV.getCount(job.search_url);
      const pageUrl = SNAV.buildPageUrl(job.search_url, job.nextStart);
      let res;
      try {
        res = await fetch(pageUrl, {
          method: 'GET',
          headers: {
            'csrf-token': csrf,
            'x-restli-protocol-version': '2.0.0',
            accept: 'application/json',
          },
          credentials: 'include',
        });
      } catch (e) {
        // Network blip: leave the job running and let the next alarm resume from the same
        // cursor. Do not advance, do not report terminal.
        job.lastError = 'Network error reaching LinkedIn — will retry.';
        await setJob(job);
        break;
      }

      // A restriction is a client incident, not an error to route around. Stop hard (§7.3).
      if (SNAV.isThrottle(res.status)) {
        job.status = 'error';
        job.httpStatus = res.status;
        job.lastError = `LinkedIn returned ${res.status} — stopped to protect the account.`;
        await setJob(job);
        await reportTerminal(token, job.id, 'error', job.lastError, res.status);
        break;
      }
      if (!res.ok) {
        job.status = 'error';
        job.httpStatus = res.status;
        job.lastError = `LinkedIn returned ${res.status} — stopped.`;
        await setJob(job);
        await reportTerminal(token, job.id, 'error', job.lastError, res.status);
        break;
      }

      let data;
      try {
        data = await res.json();
      } catch (e) {
        job.status = 'error';
        job.lastError = 'Could not parse LinkedIn response — stopped.';
        await setJob(job);
        await reportTerminal(token, job.id, 'error', job.lastError, null);
        break;
      }

      const parsed = SNAV.parseElements(data);
      if (!parsed.ok) {
        // decorationId drift or shape change — fail loudly rather than write junk (§4.3).
        job.status = 'error';
        job.lastError = parsed.reason;
        await setJob(job);
        await reportTerminal(token, job.id, 'error', job.lastError, null);
        break;
      }

      if (parsed.elements.length === 0) {
        // No more results — the search is exhausted before the page cap. Done cleanly.
        job.status = 'completed';
        await setJob(job);
        await reportTerminal(token, job.id, 'completed', 'no more results', null);
        break;
      }

      const rows = SNAV.dedupeRows(parsed.elements.map((el) => SNAV.flattenLead(el)));

      // Push this page BEFORE advancing the cursor. If the push fails we retry the same page
      // next alarm; dedupe on profile_url makes a re-push harmless.
      try {
        const ack = await postResults(token, {
          job_id: job.id,
          start: job.nextStart,
          count,
          rows,
        });
        job.rowsPushed = typeof ack.rows_received === 'number' ? ack.rows_received : job.rowsPushed + rows.length;
      } catch (e) {
        if (String(e.message) === 'unauthorized') {
          job.status = 'error';
          job.lastError = 'Token rejected by portal.';
          await setJob(job);
          break;
        }
        job.lastError = 'Could not reach portal — will retry.';
        await setJob(job);
        break;
      }

      job.nextStart += count;
      job.pagesPushed += 1;
      job.lastTickAt = Date.now();
      job.lastError = null;
      await setJob(job);

      if (job.pagesPushed >= job.max_pages) {
        job.status = 'completed';
        await setJob(job);
        await reportTerminal(token, job.id, 'completed', 'reached page cap', null);
        break;
      }

      // Gentle, jittered spacing. Under the 30s SW idle-kill window, so back-to-back paging
      // keeps the worker alive for the whole run; the persisted cursor covers the rare kill.
      await sleep(SNAV.jitterMs(CONFIG.SEARCH_MIN_DELAY_MS, CONFIG.SEARCH_MAX_DELAY_MS));
    }

    // Stop requested by the client mid-run.
    if (stopRequested) {
      job = (await getJob()) || job;
      job.status = 'stopped';
      await setJob(job);
      await reportTerminal(token, job.id, 'stopped', 'stopped by client', null);
    }
  } finally {
    jobRunning = false;
    stopRequested = false;
  }
}

// Called by the popup Stop button. Marks the job stopped so a live loop breaks and an asleep
// worker won't resume it, and reports the terminal state to the portal.
async function stopJob() {
  stopRequested = true;
  const job = await getJob();
  if (!job) return { ok: true };
  if (job.status === 'running') {
    job.status = 'stopped';
    await setJob(job);
    const { token } = await getState();
    if (token) await reportTerminal(token, job.id, 'stopped', 'stopped by client', null);
  }
  return { ok: true };
}

// The one entry point the alarm/startup use: adopt a pending job, then run it.
async function pollAndRunJob() {
  await adoptJobFromStatus();
  await runJob();
}

// ---- scheduling ----
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(ALARM, { periodInMinutes: CONFIG.POLL_MINUTES });
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(ALARM, { periodInMinutes: CONFIG.POLL_MINUTES });
  // Resume a job that was mid-run when the browser last closed (§ resume-after-restart).
  pollAndRunJob();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== ALARM) return;
  (async () => {
    await pushCookies();
    await pollAndRunJob();
  })();
});

// ---- popup messaging ----
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg.type === 'activate') sendResponse(await activate(msg.code));
    else if (msg.type === 'push-now') sendResponse(await pushCookies());
    else if (msg.type === 'get-state') sendResponse(await getState());
    else if (msg.type === 'disconnect') sendResponse(await disconnect());
    else if (msg.type === 'stop-job') sendResponse(await stopJob());
    else if (msg.type === 'check-job') { pollAndRunJob(); sendResponse({ ok: true }); }
    else sendResponse({ ok: false, error: 'unknown message' });
  })();
  return true; // async response
});
