/* Popup UI: activation + live status. All privileged work happens in background.js. */

function send(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));
}
function ago(ts) {
  if (!ts) return 'never';
  const m = Math.floor((Date.now() - ts) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m} min ago`;
  return `${Math.floor(m / 60)} hr ago`;
}
function show(id) {
  document.getElementById(id).classList.remove('hidden');
}
function hide(id) {
  document.getElementById(id).classList.add('hidden');
}
// Write only on change. render() runs on a 2.5s poll, so unconditional writes repaint
// the whole popup every tick.
function setText(id, value) {
  const el = document.getElementById(id);
  if (el.textContent !== value) el.textContent = value;
}
// The accent is set twice per render (config default, then the client's own colour after
// an await). Writing it unconditionally made the primary button flash between the two.
let appliedAccent = null;
function applyAccent(accent) {
  const next = accent || CONFIG.ACCENT;
  if (next === appliedAccent) return;
  appliedAccent = next;
  document.documentElement.style.setProperty('--accent', next);
}
// Branding never changes while the popup is open, so it is painted once, not per tick.
function applyStatic() {
  setText('brand', CONFIG.BRAND_NAME);
  setText('product', CONFIG.PRODUCT_NAME);
  document.getElementById('privacy-link').href = CONFIG.PRIVACY_URL;
  applyAccent(CONFIG.ACCENT);
}

// A slow service-worker wake can make get-state outlast the poll interval. Share the
// in-flight render so ticks and button handlers never paint over each other.
let inflight = null;
function render() {
  if (!inflight) inflight = doRender().finally(() => { inflight = null; });
  return inflight;
}

async function doRender() {
  const state = await send({ type: 'get-state' });
  if (!state || !state.token) {
    show('activate-view');
    hide('status-view');
    return;
  }

  hide('activate-view');
  show('status-view');

  applyAccent(state.accent);

  const dot = document.getElementById('conn-dot');
  const status = state.status || 'connected';
  const fresh = state.lastPush && Date.now() - state.lastPush < 15 * 60000;

  if (status === 'connected' && fresh) { dot.className = 'dot green'; setText('conn-text', 'Connected'); }
  else if (status === 'connected') { dot.className = 'dot amber'; setText('conn-text', 'Connected (syncing)'); }
  else if (status === 'logged-out') { dot.className = 'dot amber'; setText('conn-text', 'Not signed into LinkedIn'); }
  else { dot.className = 'dot red'; setText('conn-text', 'Disconnected'); }

  setText('account-line', `Account: ${state.clientName || 'your account'}`);
  setText('lastpush-line', `Last synced: ${ago(state.lastPush)}`);

  const errEl = document.getElementById('status-err');
  if (state.lastError) { errEl.textContent = state.lastError; errEl.classList.remove('hidden'); }
  else errEl.classList.add('hidden');

  renderJob(state.job);
}

// v2: show the current saved-search job (if any) with live progress and a Stop control.
// A stop is only observable once the background reports the job out of 'running', so the
// pending state is held here rather than being clobbered by the next poll.
let stopping = false;

function renderJob(job) {
  const panel = document.getElementById('job-panel');
  const jobErr = document.getElementById('job-err');
  if (!job || !job.id) { panel.classList.add('hidden'); stopping = false; return; }
  panel.classList.remove('hidden');

  const dot = document.getElementById('job-dot');
  const bar = document.getElementById('job-bar');
  const fill = document.getElementById('job-bar-fill');
  const stopBtn = document.getElementById('stop-btn');

  const live = job.status === 'running' || job.status === 'pending' || !job.status;
  if (!live) stopping = false;

  const pages = job.pagesPushed || 0;
  const rows = job.rowsPushed || 0;
  const counts = `${pages} of ${job.max_pages} pages, ${rows} ${rows === 1 ? 'lead' : 'leads'}`;

  setText('job-title', `Search: ${job.label || 'your saved search'}`);

  const showStop = () => {
    stopBtn.classList.remove('hidden');
    stopBtn.disabled = stopping;
    setText('stop-btn', stopping ? 'Stopping…' : 'Stop search');
  };
  const hideStop = () => stopBtn.classList.add('hidden');

  if (job.status === 'running') { dot.className = 'dot blue'; bar.className = 'bar'; setText('job-progress', stopping ? `Stopping — ${counts}` : `Running — ${counts}`); showStop(); }
  else if (job.status === 'completed') { dot.className = 'dot green'; bar.className = 'bar done'; setText('job-progress', `Done — ${counts}`); hideStop(); }
  else if (job.status === 'stopped') { dot.className = 'dot amber'; bar.className = 'bar halt'; setText('job-progress', `Stopped — ${counts}`); hideStop(); }
  else if (job.status === 'error') { dot.className = 'dot red'; bar.className = 'bar err'; setText('job-progress', `Stopped — ${counts}`); hideStop(); }
  else { dot.className = 'dot amber'; bar.className = 'bar'; setText('job-progress', 'Queued'); showStop(); }

  const pct = job.max_pages ? Math.min(100, Math.round((pages / job.max_pages) * 100)) : 0;
  const width = job.status === 'completed' ? '100%' : `${pct}%`;
  if (fill.style.width !== width) fill.style.width = width;

  if (job.lastError && (job.status === 'error' || job.status === 'running')) {
    jobErr.textContent = job.lastError; jobErr.classList.remove('hidden');
  } else jobErr.classList.add('hidden');
}

function updateActivateState() {
  const code = document.getElementById('code').value.trim();
  const consented = document.getElementById('consent').checked;
  document.getElementById('activate-btn').disabled = !code || !consented;
}

document.getElementById('code').addEventListener('input', updateActivateState);
document.getElementById('consent').addEventListener('change', updateActivateState);

document.getElementById('activate-btn').addEventListener('click', async () => {
  const code = document.getElementById('code').value.trim();
  const errEl = document.getElementById('activate-err');
  errEl.classList.add('hidden');
  if (!code) { errEl.textContent = 'Enter your activation code.'; errEl.classList.remove('hidden'); return; }
  const res = await send({ type: 'activate', code });
  if (!res || !res.ok) {
    errEl.textContent = (res && res.error) || 'Activation failed.';
    errEl.classList.remove('hidden');
    return;
  }
  await render();
});

document.getElementById('push-btn').addEventListener('click', async () => {
  const btn = document.getElementById('push-btn');
  if (btn.disabled) return;
  btn.disabled = true;
  btn.textContent = 'Refreshing…';
  try {
    await send({ type: 'push-now' });
    await render();
  } finally {
    btn.disabled = false;
    btn.textContent = 'Refresh now';
  }
});

document.getElementById('disconnect-btn').addEventListener('click', async () => {
  const button = document.getElementById('disconnect-btn');
  const errEl = document.getElementById('status-err');
  button.disabled = true;
  button.textContent = 'Disconnecting…';
  const result = await send({ type: 'disconnect' });
  if (!result || !result.ok) {
    errEl.textContent = result?.error || 'Disconnect failed. Please try again.';
    errEl.classList.remove('hidden');
    button.disabled = false;
    button.textContent = 'Disconnect';
    return;
  }
  await render();
  button.disabled = false;
  button.textContent = 'Disconnect';
});

// v2: stop a running saved-search job.
document.getElementById('stop-btn').addEventListener('click', async () => {
  const btn = document.getElementById('stop-btn');
  if (btn.disabled) return;
  stopping = true;
  btn.disabled = true;
  btn.textContent = 'Stopping…';
  await send({ type: 'stop-job' });
  await render();
});

// Enter-to-submit on the code field
document.getElementById('code').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('activate-btn').click();
});

applyStatic();
render();

// Opening the popup nudges the background to adopt/resume any queued job, and we re-render
// on a short interval so job progress updates live while the popup stays open.
send({ type: 'check-job' });
setInterval(render, 2500);
