/**
 * salesnav.js — pure, side-effect-free helpers for the Sales Navigator job runner.
 *
 * Extracted verbatim in behaviour from the proven prototype
 * (clients/Provident Advisor Group/tools/salesnav_voyager_pull.js, 500 leads / 20 pages,
 * 2026-08-20). Kept pure so it can be unit-tested under plain Node with no Chrome APIs —
 * see tests/salesnav.test.js. background.js loads this via importScripts and calls SNAV.*.
 *
 * Nothing here touches the network, cookies, or storage. The only moving part of a run is
 * `start` (§4.2 of the brief): everything else in the captured search URL is left verbatim.
 */
(function (root) {
  'use strict';

  const LINKEDIN_ORIGIN = 'https://www.linkedin.com';
  const DEFAULT_COUNT = 25;

  // Overwrite (or append) the `start` query param without disturbing the rest of the URL.
  function setStart(url, n) {
    return /[?&]start=/.test(url)
      ? url.replace(/([?&]start=)\d+/, `$1${n}`)
      : url + (url.includes('?') ? '&' : '?') + 'start=' + n;
  }

  // The page size LinkedIn returns. `count` is fixed per the fixtures (25) but read it back
  // from the URL so a differently-captured search still paginates correctly.
  function getCount(url) {
    const m = url.match(/[?&]count=(\d+)/);
    return m ? parseInt(m[1], 10) : DEFAULT_COUNT;
  }

  // Build the absolute page URL for a given cursor. `searchUrl` is the relative Voyager path
  // stored on the job (e.g. "/sales-api/salesApiLeadSearch?...&start=0&count=25&...").
  function buildPageUrl(searchUrl, start) {
    let path = searchUrl;
    if (!/[?&]count=/.test(path)) {
      path += (path.includes('?') ? '&' : '?') + 'count=' + DEFAULT_COUNT;
    }
    path = setStart(path, start);
    // Absolute-ise. Tolerate a job that was stored with the origin already on it.
    if (/^https?:\/\//i.test(path)) return path;
    return LINKEDIN_ORIGIN + (path.startsWith('/') ? path : '/' + path);
  }

  // A 429/403 is LinkedIn telling us to stop. Never retry through it (§7.3).
  function isThrottle(status) {
    return status === 429 || status === 403;
  }

  // Random 2.5-5.0s spacing so the cadence is not machine-flat (§7.2). `rand` is injectable
  // for deterministic tests; defaults to Math.random.
  function jitterMs(minMs, maxMs, rand) {
    const r = typeof rand === 'function' ? rand() : Math.random();
    return Math.round(minMs + r * (maxMs - minMs));
  }

  // Pull the elements array out of whatever envelope Voyager returns, and flag a shape
  // mismatch loudly (§4.3) rather than silently writing junk when decorationId drifts.
  function parseElements(data) {
    if (data && Array.isArray(data.elements)) return { ok: true, elements: data.elements };
    if (data && data.data && Array.isArray(data.data.elements)) return { ok: true, elements: data.data.elements };
    return { ok: false, elements: [], reason: 'shape-mismatch: no elements[] in response' };
  }

  const pick = (o, ...paths) => {
    for (const p of paths) {
      const v = p.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
      if (v != null && v !== '') return v;
    }
    return '';
  };

  // Flatten one raw Voyager lead element to the row shape the portal stores.
  // Identical field logic to the proven prototype's flatten().
  function flattenLead(el) {
    const pos = (el.currentPositions && el.currentPositions[0]) || el.currentPosition || {};
    return {
      first_name: pick(el, 'firstName'),
      last_name: pick(el, 'lastName'),
      full_name: pick(el, 'fullName', 'name') || `${pick(el, 'firstName')} ${pick(el, 'lastName')}`.trim(),
      title: pick(el, 'currentPositions.0.title', 'title', 'headline') || pos.title || '',
      company: pick(el, 'currentPositions.0.companyName', 'companyName') || pos.companyName || '',
      company_urn: pick(el, 'currentPositions.0.companyUrn') || pos.companyUrn || '',
      location: pick(el, 'geoRegion', 'location', 'listedLocation'),
      tenure_months: pick(el, 'currentPositions.0.tenureAtPosition.numMonths') || null,
      degree: pick(el, 'degree') || null,
      profile_url: (() => {
        const id = pick(el, 'navigationUrl', 'profileUrl');
        if (id) return String(id).split('?')[0];
        const urn = pick(el, 'entityUrn', 'objectUrn');
        return urn ? `${LINKEDIN_ORIGIN}/sales/lead/${String(urn).split(':').pop()}` : '';
      })(),
    };
  }

  // De-dupe a set of rows on profile_url (the only stable key), falling back to name|company
  // exactly as the prototype did. Server also enforces uniqueness on (client_id, profile_url);
  // this keeps each pushed page tidy.
  function dedupeRows(rows) {
    const seen = new Set();
    return rows.filter((r) => {
      const k = r.profile_url || `${r.full_name}|${r.company}`;
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  const SNAV = {
    LINKEDIN_ORIGIN,
    DEFAULT_COUNT,
    setStart,
    getCount,
    buildPageUrl,
    isThrottle,
    jitterMs,
    parseElements,
    flattenLead,
    dedupeRows,
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = SNAV;
  else root.SNAV = SNAV;
})(typeof self !== 'undefined' ? self : globalThis);
